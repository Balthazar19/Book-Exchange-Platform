package com.example.model.enums;

public enum PublicationStatus {
    PUBLISHED,
    UNPUBLISHED,
    RELEASED
}

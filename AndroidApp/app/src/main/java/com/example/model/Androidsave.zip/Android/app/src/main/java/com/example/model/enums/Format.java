package com.example.model.enums;

public enum Format {
    HARDCOVER,
    PAPERBACK
}

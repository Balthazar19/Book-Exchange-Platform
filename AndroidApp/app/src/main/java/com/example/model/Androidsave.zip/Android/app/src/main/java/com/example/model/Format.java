package com.example.model;

public class Format {
    //TODO Complete on the 3rd lecture
}

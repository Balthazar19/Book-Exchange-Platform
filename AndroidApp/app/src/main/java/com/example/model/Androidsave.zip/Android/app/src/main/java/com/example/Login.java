package com.example;

import static com.example.helpers.Constants.VALIDATE_USER;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.helpers.REST;
import com.example.model.Client;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;

import java.sql.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Login extends AppCompatActivity {

    private final Gson gson = new GsonBuilder()
            .serializeNulls()  // Include `null` values
            .registerTypeAdapter(Date.class, (JsonDeserializer<Date>)
                    (json, typeOfT, context) -> Date.valueOf(json.getAsString()))  // Deserialize for Date
            .create();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void login_submit(View view) {
        TextView login = findViewById(R.id.login_input);
        TextView psw = findViewById(R.id.password_input);

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("login", login.getText().toString());
        jsonObject.addProperty("psw", psw.getText().toString());

        String info = gson.toJson(jsonObject);
        System.out.println(info);

        Executor executor = Executors.newSingleThreadExecutor(); // background execution
        Handler handler = new Handler(Looper.getMainLooper()); // UI thread post-processing

        executor.execute(() -> {
            try {
                String response = REST.sendPost(VALIDATE_USER, info);
                handler.post(() -> {
                    try {
                        if (!response.equals("Error") && !response.equals("")) {
                            System.out.println("Server response: " + response);
                            Client client = gson.fromJson(response, Client.class); // Parse `Client`

                            int id = client.getId(); // Assuming `getId()` is part of Client
                            Intent intent = new Intent(Login.this, MainActivity.class);
                            intent.putExtra("userId", id);
                            startActivity(intent);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    // Optional: Consider adding a UserValidation class with AsyncTask usage, if needed
}
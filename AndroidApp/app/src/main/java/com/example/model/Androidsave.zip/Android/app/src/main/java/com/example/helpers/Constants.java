package com.example.helpers;

public class Constants {
    public static final String BASE_URL="http://10.21.224.108:8080/";
    public static final String VALIDATE_USER = BASE_URL + "validateClient";
    public static final String GET_ALL_PUBLICATIONS = BASE_URL + "allPublications";
}

package com.example.model.enums;

public enum Language {
    ENGLISH,
    SPANISH
}

package com.example.model.enums;

public enum Frequency {
    DAILY, WEEKLY, MONTHLY, YEARLY;
}

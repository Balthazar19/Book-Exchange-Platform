package com.example.model.enums;

public enum Genre {
    HORROR,
    SCIENCE,
    SCIENCE_FICTION,
    FANTASY
}

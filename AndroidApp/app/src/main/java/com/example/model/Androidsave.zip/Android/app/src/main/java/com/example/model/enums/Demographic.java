package com.example.model.enums;

public enum Demographic {
    CHILDREN,
    ADULT,
    TEEN
}
